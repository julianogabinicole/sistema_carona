<?php

class Crud_usuario_model extends CI_Model {

    public function cadastrar_usuario($data) {

        //  echo $razao_social;
        return $this->db->insert('tbl_cadastro_usuario', $data);
    }

    public function verifica_cadastro($cpf) {
        $this->db->where("cpf", $cpf);
        $usuario = $this->db->get("tbl_cadastro_usuario")->row_array();
        return $usuario;
    }

    //put your code here
}
