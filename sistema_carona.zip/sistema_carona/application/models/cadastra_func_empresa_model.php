 

<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Cadastra_func_empresa_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    /**
     * Método utilizado para cadastrar os cargos
     * @access public 
     * @param  $data 
     */
    public function cadastrar($data) {
        // echo $data;

        return $this->db->insert('tbl_cadastro_usuarios', $data);
    }

    /**
     * Método utilizado para consultar os dados do usuario em ordem decrescente
     * @access public 
     */
    public function retorna_alteracao() {

        $this->db->order_by('id', 'desc');
        $consulta = $this->db->get('tbl_cadastro_usuarios');

        return $consulta;
    }

    //  Método utilizado para retorna os dados da empresa
    //  Recebe com parametro para busca  $_SESSION["id_empresa"]
    public function retorna_usuario() {//$matricula = $_SESSION['matricula_enviada'];
        $id_func = $_SESSION["id_consulta"];
        $query = $this->db->where('id', $id_func);   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
        $query = $this->db->get('tbl_cadastro_usuarios');
        return $query;
    }

    /**
     * Método utilizado para atualizar os dados do usuario
     * @access public 
     * @param $data 
     */
    public function alterar_cadastro_usuario($data) {
        $id_consulta = $_SESSION["id_consulta"];
        $this->db->where('id', $id_consulta);
        return $this->db->update('tbl_cadastro_usuarios', $data);
    }

    /**
     * Método utilizado para consultar os dados do usuário 
     * @access public 
     * @param $matricula 
     */
    public function consulta_dados_usuario() {

        $query = $this->db->where('matricula', $matricula);   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
        $query = $this->db->get('tbl_cadastro_usuarios');
        return $query->row();    //   Retornamos ao controlador a fila que coincide com a busca. (FALSE no caso de não existirem coincidencias)
    }

    /**
     * Método utilizado para consultar os dados do cargo
     * @access public 
     * @param  $_SESSION["matri_empresa"]
     */
    public function consulta_dados_cargo() {

        $this->db->select('*');
        $this->db->from('tbl_cadastro_empresas');
        $this->db->join('tbl_cargo', 'tbl_cargo.matricula_empresa = tbl_cadastro_empresas.matricula', 'inner');
//$this->db->where('matricula', $_SESSION["nome_func_cargo"]); 
        $this->db->where('matricula', $_SESSION["matri_empresa"]);
        //return $consulta;
        $query = $this->db->get();
        return $query;
    }

    /**
     * Método utilizado para consultar os dados do cargo
     * @access public 
     * @param $_SESSION["id_consulta"]
     */
    public function consulta_dados_cargo_empresa($nome_cargo) {
        $this->db->where("matricula_empresa", $nome_cargo);
        $usuario = $this->db->get("tbl_cargo")->row_array();
        return $usuario;
    }

    //  Método utilizado para retorna os cargos
    //  Recebe com parametro para busca $id_cargo
    public function retorna_dados_cargo() {

        $this->db->select('*');
        $this->db->from('tbl_cadastro_usuarios');
        $this->db->join('tbl_cargo', 'tbl_cargo.matricula_empresa = tbl_cadastro_usuarios.vinculacao_func', 'inner');
        $this->db->where('id', $_SESSION["id_consulta"]);
        //return $consulta;
        $query = $this->db->get();
        return $query;
    }

    /**
     * Método utilizado para excluir os dados do usuario
     * @access public 
     * @param $id_remover
     */
    public function excluir_dado($id_remover) {

        $this->db->where('id', $id_remover);
        return $this->db->delete('tbl_cadastro_usuarios');
    }

    /**
     * Método utilizado para excluir os dados do usuario
     * @access public 
     * @param $id_remover_cadastro
     */
    public function excluir_cadastro($id_remover_cadastro) {

        $this->db->where('nome', $id_remover_cadastro);
        return $this->db->delete('tbl_cadastro_login');
    }

//  Método utilizado para retorna o cpf da empresa
    //    @access public 
    //  Recebe com parametro para busca $cpf
    public function verifica_cpf($cpf) {

        $this->db->where("cpf", $cpf);
        $usuario = $this->db->get("tbl_cadastro_usuarios")->row_array();
        return $usuario;
    }

    /**
     * Método utilizado para consultar os dados do cargo
     * @access public 
     * @param $_SESSION["matricula_logada"]
     */
    public function verifica_cargo() {

        $this->db->where("matricula_empresa", $_SESSION["matricula_logada"]);
        $usuario = $this->db->get("tbl_cargo")->row_array();
        return $usuario;
    }

    /**
     * Método utilizado para consultar os dados do usuario
     * @access public 
     * @param $_SESSION["matricula_logada"]
     */
    public function verifica_existe_usuario() {

        $this->db->where("vinculacao_func", $_SESSION["matricula_logada"]);
        $usuario = $this->db->get("tbl_cadastro_usuarios")->row_array();
        return $usuario;
    }

}
