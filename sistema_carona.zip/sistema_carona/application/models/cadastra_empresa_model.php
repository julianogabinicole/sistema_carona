﻿ 

<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Cadastra_empresa_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    /**
     * Método utilizado para cadastrar os dados da empresa
     * @access public 
     * @param $data
     */
    public function cadastrar($data) {

        //  echo $razao_social;
        return $this->db->insert('tbl_cadastro_empresas', $data);
    }

    /**
     * Método utilizado para consultar os dados da empresa
     * @access public 
     */
    public function retorna_alteracao() {

        $this->db->order_by('id', 'desc');
        $consulta = $this->db->get('tbl_cadastro_empresas');

        return $consulta;
    }

    //  Método utilizado para retorna os dados da empresa
    //  Recebe com parametro para busca  $_SESSION["id_empresa"]
    public function retorna_usuario() {
        $id_altera = $_SESSION["id_empresa"];
        //echo $matricula= $_POST['matricula'];
        $query = $this->db->where('id', $id_altera);   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
        $query = $this->db->get('tbl_cadastro_empresas');
        return $query->row();
    }

    /**
     * Método utilizado para alterar os dados da empresa
     * @access public 
     * @param  $_SESSION["id_empresa"] 
     * @param $data
     */
    public function alterar_cadastro_empresa($data) {
        //  echo $data;
        $altera_empresa = $_SESSION["id_empresa"];
        $this->db->where('id', $altera_empresa);
        return $this->db->update('tbl_cadastro_empresas', $data);
    }

    /**
     * Método utilizado para consultar os dados da empresa 
     * @access public 
     * @param $_SESSION['matricula_enviada']
     */
    public function consulta_dados_usuario() {
        $matricula = $_SESSION['matricula_enviada']; //variavel session pega da view tela_altera_usuario.php
        //   Consulta Mysql para buscar na tabela Usuario aqueles usuarios que coincidam com o mail e password inscritos na tela de login
        $query = $this->db->where('matricula', $matricula);   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
        $query = $this->db->get('tbl_cadastro_empresas');
        return $query->row();    //   Retornamos ao controlador a fila que coincide com a busca. (FALSE no caso de não existirem coincidencias)
    }

    /**
     * Método utilizado para excluir os dados da empresa
     * @access public 
     * @param $id_exclui_empresa
     */
    public function excluir_dado($id_exclui_empresa) {

        $this->db->where('id', $id_exclui_empresa);
        return $this->db->delete('tbl_cadastro_empresas');
    }

    //  Método utilizado para retorna os dados da empresa
    public function retorna_dados_empresas() {

        $this->db->order_by('id', 'desc');
        $consulta = $this->db->get('tbl_cadastro_empresas');

        return $consulta;
    }

    //  Método utilizado para retorna o cnpj da empresa
    //    @access public 
    //  Recebe com parametro para busca $cnpj
    public function verifica_cnpj($cnpj) {

        $this->db->where("cnpj", $cnpj);
        $usuario = $this->db->get("tbl_cadastro_empresas")->row_array();
        return $usuario;
    }

    /**
     * Método utilizado para consultar os dados da empresa 
     * @access public 
     */
    public function retorna_dados_empresas_cadastro() {

        $this->db->order_by('id', 'desc');
        $query = $this->db->get('tbl_cadastro_empresas');
        return $query;
    }

//  Método utilizado para retorna o valor total e soma com mais um(para matricula)
    public function ultimo_campo_id() {

        $this->db->insert_id('id');
        $consulta = $this->db->get('tbl_cadastro_empresas');
        $consulta++;
        return $consulta;
    }

}
