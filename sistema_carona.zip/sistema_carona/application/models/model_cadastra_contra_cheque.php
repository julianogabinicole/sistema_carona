<?php

class Model_cadastra_contra_cheque extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    /**
     * Método utilizado para consultar a vinculacao do usuario  
     * @access public 
     * @param $_SESSION["matricula_logada"]
     */
    public function retorna_dados_usuario_contra_cheque() {

        $this->db->order_by('id', 'desc');
        $this->db->where('vinculacao_func', $_SESSION["matricula_logada"]);
        $consulta = $this->db->get('tbl_cadastro_usuarios');
        return $consulta;
    }

    /**
     * Método utilizado para consultar e concatenar do usuario  (enviar dropdown list)
     * @access public 
     * @param $_SESSION["matricula_logada"]
     */
    public function retorna_dados_usuario_concatena_select() {
        $this->db->select(' *,CONCAT(matricula," -  ",nome) as alias_name', FALSE);
        $this->db->from('tbl_cadastro_usuarios');
        $this->db->where('vinculacao_func', $_SESSION["matricula_logada"]);
        $response = $this->db->get();
        return $response;
    }

    /**
     * Método utilizado para consultar o perido contra cheque
     * @access public 
     * @param $periodo
     *  * @param $rest
     */
    public function verifica_cadastro($periodo, $rest) {
        $this->db->where("periodo", $periodo);
        $this->db->where("nome_func", $rest);
        $usuario = $this->db->get("tbl_contra_cheque")->row_array();
        return $usuario;
    }
 /**
     * Método utilizado para juntar consultar a matricula contra cheque
     * @access public 
     * @param $periodo
     *  * @param  $_SESSION["nome_func_cargo"]
     */
    public function get_result() {

        $this->db->select('*');
        $this->db->from('tbl_cadastro_usuarios');
        $this->db->join('tbl_cargo', 'tbl_cargo.cargo_func = tbl_cadastro_usuarios.cargo', 'left');
        $this->db->where('matricula', $_SESSION["nome_func_cargo"]);
        $query = $this->db->get();
        return $query;
    }

    /**
     * Método utilizado para juntar e consultar usuarios com cargo
     * @access public 
     * @param$_SESSION["matricula_logada"]
     */
    public function get_dados_salario() {

        $this->db->select('*');
        $this->db->from('tbl_cadastro_usuarios');
        $this->db->join('tbl_cargo', 'tbl_cargo.cargo_func = tbl_cadastro_usuarios.cargo', 'inner');
        $this->db->where('matricula', $_SESSION["matricula_logada"]);
        $query = $this->db->get();
        return $query;
    }

    /**
     * Método utilizado para consultar dados do usuario
     * @access public 
     * @param$_SESSION["matricula_logada"]
     */
    public function get_contra_cheque() {


        $this->db->select('vinculacao_func');
        $this->db->from('tbl_cadastro_usuarios');
        $this->db->where('matricula', $_SESSION["matricula_logada"]);
        $query = $this->db->get();
        return $query;
    }

    /**
     * Método utilizado para consultar dados do usuario
     * @access public 
     * @param$_SESSION["matricula_logada"]
     */
    public function get_dados_contra_cheque() {

        $this->db->select('*');
        $this->db->from('tbl_cadastro_usuarios');
        $this->db->where('matricula', $_SESSION["matricula_logada"]);
        $query = $this->db->get();
        return $query;
    }

    /**
     * Método utilizado para consultar vinculacao do func usuario
     * @access public 
     * @param$_SESSION["matricula_logada"]
     */
    public function get_vinc_func() {
       echo  $_SESSION["dados_func"];
        $this->db->select('*');
        $this->db->from('tbl_cadastro_empresas');
        $this->db->where('matricula', $_SESSION["dados_func"]);
        $query = $this->db->get();
        return $query;
    }

    /**
     * Método utilizado para somar colunar e retorna com os valores 
     * @access public 
     * @param$_SESSION["matricula_logada"]
     */
    public function get_soma_contra_cheque() {

        $this->db->select_sum('desconto', 'desconto');
        $this->db->select_sum('provento', 'provento');
        $this->db->select_sum('inss', 'inss');
        $this->db->select_sum('passagem', 'passagem');
        $this->db->from('tbl_contra_cheque');
        //  $this->db->select('periodo'); 
        $this->db->where("periodo", $_SESSION["periodo"]);
        $this->db->where("nome_func", $_SESSION["matricula_logada"]);

        $query = $this->db->get();
        return $query;
    }

}
