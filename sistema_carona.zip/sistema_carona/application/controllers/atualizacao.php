<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of atualizacao
 *
 * @author Juliano
 */
class atualizacao {
      public function atualiza_senha() {
//carrega modelo
        $this->load->model('pessoas_model', 'model', TRUE);
        //
        $nova_senha = $_POST['nova_senha'];
        //codifica a senha
        $codificada = md5($nova_senha);
        $data['senha_criptografada'] = $codificada;
        $data['acesso'] = 2;

        $this->model->alterar_senha_usuario($data);
        //exibe mensagen e retorna quando efetuado   
        ?>
        <SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
            alert("A operação foi realizada com sucesso!!");

            window.location = "http://localhost/sistema_carona/";
        </SCRIPT> <?php
    }  //put your code here
}
