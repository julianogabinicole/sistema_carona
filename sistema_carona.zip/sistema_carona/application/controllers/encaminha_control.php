<?php

class Encaminha_control extends CI_Controller {

 

    public function index() {

          
        $this->load->view('tela_login_view');
   
    }
 public function login_admin() {

        $this->load->view('tela_admin');
   
    }
     public function tela_altera_senha() {

        $this->load->view('tela_altera_senha');
   
    }
      public function tela_admin() {

        $this->load->view('tela_admin');
   
    }
       public function tela_cadastro_usuario() {

        $this->load->view('cadastro_usuario_view');
   
    }
   
   
   
    
}