<?php

class Cadastros_user_control extends CI_Controller {

    public function cadastrar_usuario() {

        $unico_id = uniqid();
        $senha_md5 = md5($unico_id);
        $data['nome_solicitante'] = $this->input->post('nome_solicitante');
        $data['cpf'] = $this->input->post('cpf');
        $data['endereco'] = $this->input->post('endereco');
        $data['cidade'] = $this->input->post('cidade');
        $data['estado'] = $this->input->post('estado');
        $data['cep'] = $this->input->post('cep');
        $data['email'] = $this->input->post('email');
        $data['telefone'] = $this->input->post('telefone');
        $data['acesso'] = 1;
        $data['funcao'] = $this->input->post('funcao');
        //primeiro cadastra em uma tabela
        $this->load->model('crud_usuario_model', 'model', TRUE);
        $ExisteCpfCadastrado = $this->model->verifica_cadastro($_POST['cpf']);
        

        if ($ExisteCpfCadastrado == "") {
            $this->load->model('crud_usuario_model', 'model', TRUE);
            $this->model->cadastrar_usuario($data);
            ?><SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
                alert("A operação foi realizada com sucesso!");

                window.location = "http://localhost:8080/sistema_carona/index.php/encaminha_control/tela_login_view";
            </SCRIPT><?php
        } else
            
            ?><SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
            alert("Usuário já cadastrado!");

            window.location = "http://localhost:8080/sistema_carona/index.php/encaminha_control/tela_cadastro_usuario";
        </SCRIPT><?php
    }

}
