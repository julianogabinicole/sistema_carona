
<!DOCTYPE html>
<html lang="pt-BR">
    <head>

        <meta charset="iso-8859-1" />
        <link rel="stylesheet" type="text/css" href="http://localhost/CodeIgniter/css/formulario.css">  

    </head>
    <body>





        <?php echo $nome; ?>



    </form>

</body>
</html>