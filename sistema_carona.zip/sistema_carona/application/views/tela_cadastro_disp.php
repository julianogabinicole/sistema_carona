<link rel="shortcut icon" href="http://localhost:8080/sistema_carona/dist/img/carona_sol.jpg" >
<title>Sistema de Carona</title>

<script src="http://localhost:8080/sistema_carona/js/bootstrap.min.js"></script>
<link href="http://localhost:8080/sistema_carona/css/bootstrap.min.css" rel="stylesheet">   
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<link rel="stylesheet" 
href="http://localhost:8080/sistema_carona/css/jquery.dataTables.min.css"></style>
<script type="text/javascript" 
src="http://localhost:8080/sistema_carona/js/consulta_tela.js"></script>
<link rel="stylesheet" type="text/css" href="http://localhost:8080/sistema_carona/css/form_padrao_cadastro.css">

<script type="text/javascript">
    function id(el) {
        return document.getElementById(el);
    }
    function mostra(el) {
        id(el).style.display = 'block';
    }
    function esconde_todos(el, tagName) {
        var tags = el.getElementsByTagName(tagName);
        for (var i = 0; i < tags.length; i++)
        {
            tags[i].style.display = 'none';
        }
    }
    window.onload = function ()
    {
        id('Passageiro').style.display = 'none';
        id('Motorista').style.display = 'none';

        id('sel_funcao').onchange = function ()
        {
            esconde_todos(id('funcao'), 'div');
            mostra(this.value);
        }
        var radios = document.getElementsByTagName('input');
        for (var i = 0; i < radios.length; i++) {
            if (radios[i].type == 'radio')
            {
                radios[i].onclick = function () {
                    esconde_todos(id('funcao'), 'div');
                    mostra(this.value);
                }
            }
        }
    }
</script>

<div id="box" class="card card-container">
    <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
    <img id="profile-img" class="profile-img-card" src="http://localhost:8080/sistema_carona/dist/img/carona_sol.jpg" />

    <body>
        <h3>Selecione::</h3>
        <label><input type="radio" size="45" name="selecione_disp" id="sel_funcao" class="form-control"value="Motorista" />Motorista</label><p>
            <label><input type="radio" size="45" name="selecione_disp" id="sel_funcao"class="form-control" value="Passageiro" />Passageiro</label>

        <div id="funcao">
            <div id="Motorista">
                <form class="form-inline" method="post"  accept-charset="utf-8" action="http://localhost:8080/sistema_carona/index.php/crud_registros_control/cadastrar_encontro">       


                    <input type="text"  size="45" maxlength="20" class="form-control" name="carro" placeholder="Informe o fabricante" required autofocus><br><br>
                    <input type="text"  size="45" maxlength="20" class="form-control" name="modelo" placeholder="Informe o modelo" required autofocus><br><br>
                    <input type="text"  size="45" maxlength="20" class="form-control" name="cor" placeholder="Informe a cor" required autofocus><br><br>
                    <input type="text"  size="45" maxlength="20" class="form-control" name="placa" placeholder="Informe a placa" required autofocus><br><br>
                    Observacao:<textarea></textarea>
                    <br> <br> <button class="btn btn-lg btn-primary btn-block btn-signin" name="botao_motorista" type="submit">Cadastrar</button>
                </form><!-- /form -->        
            </div>
    </body>
    <body>
        <div id="Passageiro">
            <form class="form-inline" method="post"  accept-charset="utf-8" action="http://localhost:8080/sistema_carona/index.php/crud_registros_control/buscar_encontro">       

                <h6>Efetuar busca(Sera buscado a carona mais proxima)::</h6>
                <br>   <button class="btn btn-lg btn-primary btn-block btn-signin" name="botao_passageiro" type="submit">Buscar</button></div>
</div>
</div>
<body>

</tr>
</div><!-- /card-container -->
</div><!-- /container -->


