<link rel="shortcut icon" href="http://localhost:8080/sistema_carona/dist/img/carona_sol.jpg" >
<title>Sistema de Carona</title>

<script src="http://localhost:8080/sistema_carona/js/bootstrap.min.js"></script>

<link href="http://localhost:8080/sistema_carona/css/bootstrap.min.css" rel="stylesheet">   
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<link rel="stylesheet" 
href="http://localhost:8080/sistema_carona/css/jquery.dataTables.min.css"></style>
<script type="text/javascript" 
src="http://localhost:8080/sistema_carona/js/consulta_tela.js"></script>



<script>

    $(document).ready(function () {
        $('#minhaTabela').dataTable();
    });
</script>



<html lang="pt-BR">
    <head>

        <meta charset="UTF-8" />

        <link rel="stylesheet" type="text/css" href="http://localhost:8080/sistema_carona/css/form_exibe_relatorio.css">  

    </head>
    <body>
        <div class="form-group"  top:20px; left:6px;">
             <div id="box" class="card card-container">
                 <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
                <div class="table-responsive">
                <h2>Painel de Controle de Acesso</h2><br>
                    <table id="minhaTabela" class="display table" width="100%" >

                        <thead>  
                            <tr>  
                                <th width="4%">Código</th> 
                                <th width="10%">Nome</th> 
                                <th width="10%">CPF</th> 
                                <th width="10%">Endereço</th> 
                                <th width="10%">CEP</th> 
                                <th width="10%">Email</th>
                                <th width="20%">Telefone</th> 
                                
                                <th width="10%"></th> 
                                <th width="10%"></th> 

                            </tr>  
                        </thead>  
                        <tbody>
                            <?php foreach ($dados as $dados) { ?>
                                <tr>  
                                    <td><?= $dados->codigo_usuario; ?> </td> 
                                    <td><?= $dados->nome_solicitante; ?> </td>
                                    <td><?= $dados->cpf; ?> </td>
                                    <td><?= $dados->endereco; ?> </td>
                                    <td><?= $dados->cep; ?> </td>
                                    <td><?= $dados->email; ?> </td>
                                    <td><?= $dados->telefone; ?> </td>
                                    

                            <form class="form-signin" method="post" accept-charset="utf-8"  action="http://localhost:8080/sistema_carona/index.php/crud_registros_control/exclui" id="form">
                                <td><button  name="excluir" class="btn btn-danger" type="submit">Remover</button>
                                    <input name="id_remover"  type="hidden" id="id_remover" value="<?= $dados->codigo_usuario; ?>"</td>
                            </form>
                            <form class="form-signin" method="post" accept-charset="utf-8"  action="http://localhost:8080/sistema_carona/index.php/crud_registros_control/cadastrar" id="form">
                                <td><button  name="cadastrar" class="btn btn-primary"  type="submit">Cadastrar</button>
                                          <input name="id_cadastrar"  type="hidden" id="id_cadastrar" value="<?= $dados->codigo_usuario; ?>"</td>
                                    <input name="nome_solicitante"  type="hidden" id="nome_solicitante" value="<?= $dados->nome_solicitante; ?>"</td>
                                <input name="cpf"  type="hidden" id="cpf" value="<?= $dados->cpf; ?>"</td>
                                <input name="endereco"  type="hidden" id="endereco" value="<?= $dados->endereco; ?>"</td>
                                <input name="cep"  type="hidden" id="cep" value="<?= $dados->cep; ?>"</td>
                                <input name="email"  type="hidden" id="email" value="<?= $dados->email; ?>"</td>
                                <input name="telefone"  type="hidden" id="telefone" value="<?= $dados->telefone; ?>"</td>
                               
                            </form>


                            </tr>
                        <?php } ?>
                        </tbody>  
                    </table>

                </div>       </div> 
        </div>
</html>
