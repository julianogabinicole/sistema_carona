<link rel="shortcut icon" href="http://localhost:8080/sistema_carona/dist/img/carona_sol.jpg" >
<title>Sistema de Carona</title>
<style type="text/css">
    #box{

        border-radius: 10px;
    }

</style><!DOCTYPE html>
<head>
    <meta charset="UTF-8" />

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <script type="text/javascript" 
    src="http://localhost:8080/sistema_carona/js/tratamento_campos.js"></script>
    <script type="text/javascript" src="http://localhost:8080/sistema_carona/js/trata_campo_cpf.js"></script>
    <script type="text/javascript" src="http://localhost:8080/sistema_carona/js/trata_cpf.js"></script>   
    <link rel="stylesheet" href="dist/css/bootstrap-select.css">      
</head>
<html lang="pt-BR">
    <head>
        <title><?php echo $titulo; ?></title>
        <meta charset="UTF-8" />
        <link rel="stylesheet" type="text/css" href="http://localhost:8080/sistema_carona/css/form_cadastro_usuario.css">  

    </head>
    <body>
        <form class="form-signin" id="form" name="form" method="post" accept-charset="utf-8" action="http://localhost:8080/sistema_carona/index.php/cadastros_user_control/cadastrar_usuario">

            <div id="box" class="card card-container">

                <table>
                    <tr><h2>Cadastrar Usuário <h2></tr>
                            </table>

                            Nome  : *  <input onKeypress="return somente_letras(event)"  maxlength="30" type="text" 
                                              class="form-control"inputEmail name="nome_solicitante" placeholder="Nome" required autofocus>
                            CPF  : * <input type="text"   onKeyPress="return Apenas_Numeros(event);" onBlur="validaCPF(this);" 
                                            title="Digite o CPF no formato nnn.nnn.nnn-nn" id="cpf" class="form-control" size="11" 
                                            maxlength="14" name="cpf" placeholder="xxx.xxx.xxx-xx" required>

                            Endereço : *<input type="text" placeholder="Endereço" class="form-control" name="endereco" maxlength="100" required="required">
                            Cidade : *<input type="text" placeholder="Cidade" class="form-control" name="cidade" maxlength="100" required="required">
                            UF :    <select id="inputEmail" name="estado" class="form-control">
                                <option value="">----Selecione----</option>
                                <option value="DF">Distrito Federal</option>
                                <option value="SP">São Paulo</option>
                                <option value="RJ">Rio de Janeiro</option>
                                <option value="RN">Rio Grande do Norte</option>

                            </select> 
                            CEP :<input type="text" placeholder="CEP"  class="form-control"  name="cep" maxlength="30" required="required">
                            E-mail para contato : * <input type="text" placeholder="Email"  class="form-control"   name="email" maxlength="30" required="required">
                            Telefone: * <input type="text"  class="form-control"  onKeyPress="fone(this, document.form.data)"  class="form-control" name="telefone" maxlength="14" pattern="\([0-9]{2}\)[0-9]{4}-[0-9]{4}" placeholder="(xx) xxxx-xxxx" required>
                            </select>
                            <label><input type="radio" size="45" name="funcao" id="sel_funcao" class="form-control"value="Motorista" />Motorista</label>
                            <label><input type="radio" size="45" name="funcao" id="sel_funcao"class="form-control" value="Passageiro" />Passageiro</label>
                            <br>   <br>  
                            <button name="botao" class="btn btn-lg btn-primary btn-block btn-signin" type="submit">Cadastrar</button><br>
                            <tr align="center"><td>   
                                    <a href="http://localhost:8080/sistema_carona/index.php/encaminha_control/login_admin" class="forgot-password">
                                        Voltar
                                    </a></td>
                            </tr>              
                            </div>
                            </form>




                            </body>
                            </html>