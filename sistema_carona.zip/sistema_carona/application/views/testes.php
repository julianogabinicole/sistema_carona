<html>
<head>
<script type="text/javascript">
function id( el ){
        return document.getElementById( el );
}
function mostra( el ){
        id( el ).style.display = 'block';
}
function esconde_todos( el, tagName ){
        var tags = el.getElementsByTagName( tagName );
        for( var i=0; i<tags.length; i++ )
        {
                tags[i].style.display = 'none';
        }
}
window.onload = function()
{
        id('Passageiro').style.display = 'none';
        id('Motorista').style.display = 'none';

        id('sel_funcao').onchange = function()
        {
                esconde_todos( id('funcao'), 'div' );
                mostra( this.value );
        }
        var radios = document.getElementsByTagName('input');
        for( var i=0; i<radios.length; i++ ){
                if( radios[i].type=='radio' )
                {
                        radios[i].onclick = function(){
                                esconde_todos( id('funcao'), 'div' );
                                mostra( this.value );
                        }
                }
        }
}
</script>
</head>
<body>

     
        <label><input type="radio" name="selecione_disp" id="sel_funcao" value="Motorista" />Motorista</label>
        <label><input type="radio" name="selecione_disp" id="sel_funcao"value="Passageiro" />Passageiro</label>

        <div id="funcao">
                <div id="Passageiro">Seu sexo é Passageiro!</div>
                <div id="Motorista">Seu sexo é Motorista!</div>
        </div>
</body>
</html>