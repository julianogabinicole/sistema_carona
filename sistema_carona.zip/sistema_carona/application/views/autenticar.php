<!DOCTYPE html>
<html>
    <head>
        <title>Bem vindo</title>
    </head>
    <body>
        <?= $mensagem ?>
    </body>
</html>