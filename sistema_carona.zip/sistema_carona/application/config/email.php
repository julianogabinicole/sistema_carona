<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/*
  | -------------------------------------------------------------------
  | EMAIL CONFING
  | -------------------------------------------------------------------
  | Configuration of outgoing mail server.
  | */
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'ssl://smtp.googlemail.com';
$config['smtp_port'] = '465';
$config['smtp_timeout'] = '60';
$config['smtp_user'] = 'phpthc@gmail.com';
$config['smtp_pass'] = '010148jps';
$config['charset'] = 'utf-8';
$config['newline'] = "\r\n";


